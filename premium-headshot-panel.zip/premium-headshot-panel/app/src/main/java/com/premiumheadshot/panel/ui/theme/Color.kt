package com.premiumheadshot.panel.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Dark Palette
val ObsidianBlack = Color(0xFF0A0A0F)
val CharcoalSurface = Color(0xFF15151D)
val GlassSurface = Color(0x1AFFFFFF)
val RoyalBlue = Color(0xFF3D5AFE)
val RoyalBlueDeep = Color(0xFF1A237E)
val SilverText = Color(0xFFE8E8ED)
val SilverMuted = Color(0xFF9797A6)
val PlatinumAccent = Color(0xFFC9CDD6)
val DividerSubtle = Color(0x1FFFFFFF)

// Light Palette
val PearlWhite = Color(0xFFFAFAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightGlass = Color(0x0D000000)
val InkText = Color(0xFF15151D)
val InkMuted = Color(0xFF6B6B76)
