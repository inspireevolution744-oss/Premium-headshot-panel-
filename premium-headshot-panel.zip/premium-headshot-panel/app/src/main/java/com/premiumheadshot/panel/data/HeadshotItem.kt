package com.premiumheadshot.panel.data

import android.net.Uri

/**
 * Represents a single headshot loaded from the device.
 * No cloud sync, no user ID, no account linkage — fully local.
 */
data class HeadshotItem(
    val id: String,
    val uri: Uri,
    val name: String,
    val dateAdded: Long = System.currentTimeMillis()
)
