package com.premiumheadshot.panel.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkPremiumScheme = darkColorScheme(
    primary = RoyalBlue,
    onPrimary = SilverText,
    secondary = PlatinumAccent,
    background = ObsidianBlack,
    onBackground = SilverText,
    surface = CharcoalSurface,
    onSurface = SilverText,
    surfaceVariant = GlassSurface,
    onSurfaceVariant = SilverMuted,
    outline = DividerSubtle
)

private val LightPremiumScheme = lightColorScheme(
    primary = RoyalBlueDeep,
    onPrimary = LightSurface,
    secondary = InkMuted,
    background = PearlWhite,
    onBackground = InkText,
    surface = LightSurface,
    onSurface = InkText,
    surfaceVariant = LightGlass,
    onSurfaceVariant = InkMuted,
    outline = LightGlass
)

@Composable
fun PremiumHeadshotPanelTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkPremiumScheme else LightPremiumScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = PremiumTypography,
        content = content
    )
}
