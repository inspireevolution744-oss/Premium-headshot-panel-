package com.premiumheadshot.panel

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.premiumheadshot.panel.data.HeadshotItem
import com.premiumheadshot.panel.screens.HomeScreen
import com.premiumheadshot.panel.screens.PreviewScreen
import com.premiumheadshot.panel.ui.theme.PremiumHeadshotPanelTheme
import java.net.URLDecoder
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PremiumHeadshotPanelTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PremiumHeadshotApp()
                }
            }
        }
    }
}

@Composable
fun PremiumHeadshotApp() {
    val navController = rememberNavController()

    // Local-only in-memory state. No cloud, no account, no ID required.
    val headshots = remember { mutableStateListOf<HeadshotItem>() }

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val newItem = HeadshotItem(
                id = System.currentTimeMillis().toString(),
                uri = it,
                name = "Headshot ${headshots.size + 1}"
            )
            headshots.add(newItem)
        }
    }

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                headshots = headshots,
                onAddClick = { pickImageLauncher.launch("image/*") },
                onHeadshotClick = { item ->
                    val encodedUri = URLEncoder.encode(item.uri.toString(), "UTF-8")
                    navController.navigate("preview/${item.id}/$encodedUri/${item.name}")
                },
                onDeleteClick = { item -> headshots.remove(item) }
            )
        }
        composable(
            route = "preview/{id}/{uri}/{name}",
            arguments = listOf(
                navArgument("id") { type = NavType.StringType },
                navArgument("uri") { type = NavType.StringType },
                navArgument("name") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id") ?: ""
            val uriString = backStackEntry.arguments?.getString("uri") ?: ""
            val name = backStackEntry.arguments?.getString("name") ?: "Headshot"
            val decodedUri = URLDecoder.decode(uriString, "UTF-8")

            PreviewScreen(
                item = HeadshotItem(id = id, uri = Uri.parse(decodedUri), name = name),
                onBack = { navController.popBackStack() }
            )
        }
    }
}
